export const dynamic = 'force-dynamic';

import { NextResponse } from 'next/server';

export async function POST() {
  return NextResponse.json({ message: 'Lütfen /api/auth/callback/credentials kullanın' }, { status: 200 });
}
