import { PrismaClient } from '@prisma/client';
import bcrypt from 'bcryptjs';

const prisma = new PrismaClient();

async function main() {
  // Admin user (test account)
  const adminPassword = await bcrypt.hash('johndoe123', 12);
  await prisma.user.upsert({
    where: { email: 'john@doe.com' },
    update: {},
    create: {
      email: 'john@doe.com',
      password: adminPassword,
      firstName: 'Admin',
      lastName: 'User',
      phone: '05551234567',
      role: 'ADMIN',
    },
  });

  // Default settings
  const defaultSettings: { key: string; value: string }[] = [
    { key: 'iban', value: 'TR00 0000 0000 0000 0000 0000 00' },
    { key: 'account_holder', value: 'DüğünKare' },
    { key: 'whatsapp_number', value: '905551234567' },
    { key: 'instagram', value: 'dugunkareci' },
    { key: 'price_basic', value: '500' },
    { key: 'price_premium', value: '1000' },
    { key: 'price_print_10x15', value: '15' },
    { key: 'price_print_13x18', value: '25' },
    { key: 'price_print_15x21', value: '35' },
    { key: 'price_canvas_a4', value: '150' },
    { key: 'price_canvas_a3', value: '250' },
    { key: 'price_canvas_50x70', value: '400' },
  ];

  for (const setting of defaultSettings) {
    await prisma.setting.upsert({
      where: { key: setting.key },
      update: {},
      create: setting,
    });
  }

  console.log('Seed completed successfully!');
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
