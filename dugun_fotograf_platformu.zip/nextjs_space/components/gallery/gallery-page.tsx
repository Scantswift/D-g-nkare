'use client';

import { useEffect, useState, useCallback, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Heart, Camera, Upload, X, Download, ChevronLeft, ChevronRight, User, MessageCircle, Image as ImageIcon } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Progress } from '@/components/ui/progress';
import { formatDate } from '@/lib/utils';
import { toast } from 'sonner';

interface Photo {
  id: string;
  url: string;
  fileName: string;
  uploaderName: string | null;
  contentType: string;
  createdAt: string;
}

interface WeddingData {
  id: string;
  groomName: string;
  brideName: string;
  weddingDate: string;
  venue: string | null;
  slug: string;
  photos: Photo[];
}

export function GalleryPage({ slug }: { slug: string }) {
  const [wedding, setWedding] = useState<WeddingData | null>(null);
  const [loading, setLoading] = useState(true);
  const [uploading, setUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [uploaderName, setUploaderName] = useState('');
  const [lightboxIndex, setLightboxIndex] = useState<number | null>(null);
  const [settings, setSettings] = useState<Record<string, string>>({});
  const fileInputRef = useRef<HTMLInputElement>(null);

  const fetchGallery = useCallback(async () => {
    try {
      const res = await fetch(`/api/gallery/${slug}`);
      if (res.ok) setWedding(await res.json());
    } catch { /* ignore */ } finally { setLoading(false); }
  }, [slug]);

  useEffect(() => {
    fetchGallery();
    fetch('/api/settings').then(r => r.ok ? r.json() : {}).then(d => setSettings(d ?? {})).catch(() => {});
  }, [fetchGallery]);

  const handleUpload = async (files: FileList | null) => {
    if (!files || files.length === 0) return;
    setUploading(true);
    setUploadProgress(0);
    const total = files.length;
    let done = 0;

    for (let i = 0; i < total; i++) {
      const file = files[i];
      if (!file) continue;
      try {
        // Get presigned URL
        const presRes = await fetch('/api/upload/presigned', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ fileName: file.name, contentType: file.type, isPublic: true }),
        });
        if (!presRes.ok) continue;
        const { uploadUrl, cloud_storage_path } = await presRes.json();
        
        // Upload to S3
        await fetch(uploadUrl, {
          method: 'PUT',
          headers: { 'Content-Type': file.type },
          body: file,
        });
        
        // Save record
        await fetch(`/api/gallery/${slug}/upload`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            cloudStoragePath: cloud_storage_path,
            fileName: file.name,
            contentType: file.type,
            uploaderName: uploaderName || '',
            isPublic: true,
          }),
        });
        done++;
        setUploadProgress(Math.round((done / total) * 100));
      } catch {
        toast.error(`${file.name} yüklenemedi`);
      }
    }

    toast.success(`${done} dosya başarıyla yüklendi!`);
    setUploading(false);
    setUploadProgress(0);
    fetchGallery();
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    handleUpload(e.dataTransfer?.files ?? null);
  };

  const photos = wedding?.photos ?? [];

  const downloadPhoto = (photo: Photo) => {
    const a = document.createElement('a');
    a.href = photo.url;
    a.download = photo.fileName ?? 'photo';
    a.click();
  };

  const whatsappNumber = settings?.whatsapp_number ?? '905551234567';
  const whatsappMessage = encodeURIComponent(`Merhaba, ${wedding?.groomName ?? ''} & ${wedding?.brideName ?? ''} düğününden baskı/tablo siparişi vermek istiyorum.`);

  if (loading) return (
    <div className="min-h-screen bg-background flex items-center justify-center">
      <div className="text-center">
        <Heart className="h-12 w-12 text-primary animate-pulse mx-auto mb-4" />
        <p className="text-muted-foreground">Galeri yükleniyor...</p>
      </div>
    </div>
  );

  if (!wedding) return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <Card className="max-w-md w-full text-center">
        <CardContent className="p-8">
          <Heart className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
          <h2 className="font-display text-xl font-bold mb-2">Düğün Bulunamadı</h2>
          <p className="text-muted-foreground">Bu link geçersiz veya düğün galerisi kapatılmış olabilir.</p>
        </CardContent>
      </Card>
    </div>
  );

  return (
    <div className="min-h-screen bg-background">
      {/* Hero */}
      <div className="bg-gradient-to-br from-primary/10 via-background to-secondary/30 py-12 md:py-16">
        <div className="max-w-[1200px] mx-auto px-4 text-center">
          <Heart className="h-10 w-10 text-primary fill-primary mx-auto mb-4" />
          <h1 className="font-display text-3xl md:text-5xl font-bold tracking-tight mb-2">
            {wedding.groomName} & {wedding.brideName}
          </h1>
          <p className="text-muted-foreground text-lg">{formatDate(wedding.weddingDate)}</p>
          {wedding.venue && <p className="text-muted-foreground text-sm mt-1">{wedding.venue}</p>}
          <p className="text-sm text-muted-foreground mt-4">{photos.length} fotoğraf paylaşıldı</p>
        </div>
      </div>

      <div className="max-w-[1200px] mx-auto px-4 py-8 space-y-8">
        {/* Upload Section */}
        <Card className="border-0 shadow-lg overflow-hidden">
          <CardContent className="p-6 md:p-8">
            <h2 className="font-display text-xl font-bold mb-4 flex items-center gap-2">
              <Upload className="h-5 w-5 text-primary" /> Fotoğraf / Video Yükle
            </h2>
            <div className="mb-4">
              <label className="text-sm text-muted-foreground mb-1.5 block">Adınız (opsiyonel)</label>
              <div className="relative max-w-xs">
                <User className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input placeholder="Ör: Mehmet Amca" className="pl-10" value={uploaderName} onChange={(e: any) => setUploaderName(e?.target?.value ?? '')} />
              </div>
            </div>
            <div
              onDrop={handleDrop}
              onDragOver={(e: React.DragEvent) => e.preventDefault()}
              onClick={() => fileInputRef.current?.click?.()}
              className="border-2 border-dashed border-primary/30 rounded-xl p-8 md:p-12 text-center cursor-pointer hover:border-primary/60 hover:bg-primary/5 transition-all"
            >
              <Camera className="h-12 w-12 text-primary/50 mx-auto mb-4" />
              <p className="font-medium">Fotoğraf veya video seçin ya da sürükleyin</p>
              <p className="text-sm text-muted-foreground mt-1">Birden fazla dosya seçebilirsiniz</p>
              <input
                ref={fileInputRef}
                type="file"
                multiple
                accept="image/*,video/*"
                className="hidden"
                onChange={(e: any) => handleUpload(e?.target?.files ?? null)}
              />
            </div>
            {uploading && (
              <div className="mt-4">
                <Progress value={uploadProgress} className="h-2" />
                <p className="text-sm text-muted-foreground mt-2 text-center">Yükleniyor... %{uploadProgress}</p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Gallery */}
        <div>
          <h2 className="font-display text-xl font-bold mb-4 flex items-center gap-2">
            <ImageIcon className="h-5 w-5 text-primary" /> Galeri
          </h2>
          {photos.length === 0 ? (
            <Card className="border-dashed">
              <CardContent className="p-12 text-center">
                <Camera className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                <p className="text-muted-foreground">Henüz fotoğraf yok. İlk fotoğrafı siz yükleyin!</p>
              </CardContent>
            </Card>
          ) : (
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 md:gap-4">
              {photos.map((p: Photo, i: number) => (
                <motion.div key={p.id} initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} transition={{ delay: i * 0.03 }}>
                  <Card className="overflow-hidden group cursor-pointer" onClick={() => setLightboxIndex(i)}>
                    <div className="aspect-square relative bg-muted">
                      {p.contentType?.startsWith('video/') ? (
                        <video src={p.url} className="w-full h-full object-cover" muted />
                      ) : (
                        <img src={p.url} alt={p.fileName ?? 'Fotoğraf'} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" loading="lazy" />
                      )}
                      <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-all" />
                    </div>
                    {p.uploaderName && (
                      <div className="p-2">
                        <p className="text-xs text-muted-foreground truncate">{p.uploaderName}</p>
                      </div>
                    )}
                  </Card>
                </motion.div>
              ))}
            </div>
          )}
        </div>

        {/* WhatsApp Contact */}
        <Card className="border-0 shadow-lg bg-gradient-to-r from-green-50 to-green-100/50 dark:from-green-950/20 dark:to-green-900/10">
          <CardContent className="p-6 md:p-8 text-center">
            <MessageCircle className="h-10 w-10 text-green-600 mx-auto mb-4" />
            <h2 className="font-display text-xl font-bold mb-2">Baskı & Tablo Siparişi</h2>
            <p className="text-muted-foreground mb-4 max-w-md mx-auto">
              Fotoğraflarınızı baskı veya tablo olarak sipariş etmek için WhatsApp üzerinden bize ulaşın.
            </p>
            <a href={`https://wa.me/${whatsappNumber}?text=${whatsappMessage}`} target="_blank" rel="noopener noreferrer">
              <Button size="lg" className="bg-green-600 hover:bg-green-700 text-white gap-2">
                <MessageCircle className="h-5 w-5" /> WhatsApp ile İletişime Geç
              </Button>
            </a>
          </CardContent>
        </Card>

        {/* Footer */}
        <div className="text-center py-4">
          <a href="/" className="inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-primary transition-colors">
            <Heart className="h-3.5 w-3.5" /> DüğünKare ile oluşturuldu
          </a>
        </div>
      </div>

      {/* Lightbox */}
      <AnimatePresence>
        {lightboxIndex !== null && photos[lightboxIndex] && (
          <motion.div
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/90 flex items-center justify-center"
            onClick={() => setLightboxIndex(null)}
          >
            <Button size="icon" variant="ghost" className="absolute top-4 right-4 text-white hover:bg-white/20 z-10" onClick={() => setLightboxIndex(null)}>
              <X className="h-6 w-6" />
            </Button>
            <Button size="icon" variant="ghost" className="absolute left-4 top-1/2 -translate-y-1/2 text-white hover:bg-white/20 z-10"
              onClick={(e: any) => { e?.stopPropagation?.(); setLightboxIndex(Math.max(0, (lightboxIndex ?? 0) - 1)); }}>
              <ChevronLeft className="h-6 w-6" />
            </Button>
            <Button size="icon" variant="ghost" className="absolute right-4 top-1/2 -translate-y-1/2 text-white hover:bg-white/20 z-10"
              onClick={(e: any) => { e?.stopPropagation?.(); setLightboxIndex(Math.min((photos?.length ?? 1) - 1, (lightboxIndex ?? 0) + 1)); }}>
              <ChevronRight className="h-6 w-6" />
            </Button>
            <div className="max-w-[90vw] max-h-[85vh] relative" onClick={(e: any) => e?.stopPropagation?.()}>
              {photos[lightboxIndex]?.contentType?.startsWith('video/') ? (
                <video src={photos[lightboxIndex]?.url} controls className="max-w-full max-h-[85vh] rounded-lg" />
              ) : (
                <img src={photos[lightboxIndex]?.url} alt="" className="max-w-full max-h-[85vh] object-contain rounded-lg" />
              )}
              <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex gap-2">
                <Button size="sm" className="bg-white/20 hover:bg-white/30 text-white backdrop-blur-sm gap-1.5" onClick={() => downloadPhoto(photos[lightboxIndex!]!)}>
                  <Download className="h-3.5 w-3.5" /> İndir
                </Button>
              </div>
            </div>
            <p className="absolute bottom-4 left-1/2 -translate-x-1/2 text-white/60 text-sm">
              {(lightboxIndex ?? 0) + 1} / {photos?.length ?? 0}
            </p>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
