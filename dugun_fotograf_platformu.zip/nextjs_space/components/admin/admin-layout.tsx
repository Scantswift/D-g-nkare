'use client';

import { useSession, signOut } from 'next-auth/react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { Heart, LayoutDashboard, ShoppingCart, Settings, LogOut, Menu, X, ArrowLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useState } from 'react';

export function AdminLayout({ children }: { children: React.ReactNode }) {
  const { data: session } = useSession() || {};
  const pathname = usePathname();
  const [mobileOpen, setMobileOpen] = useState(false);

  const navItems = [
    { href: '/admin', label: 'Dashboard', icon: LayoutDashboard },
    { href: '/admin/siparisler', label: 'Siparişler', icon: ShoppingCart },
    { href: '/admin/ayarlar', label: 'Ayarlar', icon: Settings },
  ];

  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-50 bg-background/80 backdrop-blur-md border-b border-border/50">
        <div className="max-w-[1200px] mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" className="md:hidden" onClick={() => setMobileOpen(!mobileOpen)}>
              {mobileOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </Button>
            <Link href="/admin" className="flex items-center gap-2">
              <Heart className="h-6 w-6 text-primary fill-primary" />
              <span className="font-display text-xl font-bold tracking-tight">Admin Panel</span>
            </Link>
          </div>
          <nav className="hidden md:flex items-center gap-1">
            {navItems.map((item: any) => (
              <Link key={item.href} href={item.href}>
                <Button variant={pathname === item.href ? 'secondary' : 'ghost'} size="sm" className="gap-2">
                  <item.icon className="h-4 w-4" /> {item.label}
                </Button>
              </Link>
            ))}
          </nav>
          <div className="flex items-center gap-3">
            <Link href="/dashboard"><Button variant="ghost" size="sm" className="gap-2"><ArrowLeft className="h-4 w-4" /> Dashboard</Button></Link>
            <Button variant="ghost" size="sm" onClick={() => signOut({ callbackUrl: '/' })} className="gap-2">
              <LogOut className="h-4 w-4" /> Çıkış
            </Button>
          </div>
        </div>
      </header>
      {mobileOpen && (
        <div className="md:hidden border-b border-border bg-background p-4 space-y-2">
          {navItems.map((item: any) => (
            <Link key={item.href} href={item.href} onClick={() => setMobileOpen(false)}>
              <Button variant={pathname === item.href ? 'secondary' : 'ghost'} className="w-full justify-start gap-2">
                <item.icon className="h-4 w-4" /> {item.label}
              </Button>
            </Link>
          ))}
        </div>
      )}
      <main className="max-w-[1200px] mx-auto px-4 py-8">{children}</main>
    </div>
  );
}
