'use client';

import { useEffect, useState } from 'react';
import { Settings, Save, CreditCard, Instagram, Phone } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { toast } from 'sonner';

export function AdminSettings() {
  const [settings, setSettings] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    fetch('/api/settings')
      .then(r => r.ok ? r.json() : {})
      .then(d => setSettings(d ?? {}))
      .catch(() => {})
      .finally(() => setLoading(false));
  }, []);

  const handleSave = async () => {
    setSaving(true);
    try {
      const res = await fetch('/api/settings', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(settings),
      });
      if (res.ok) toast.success('Ayarlar kaydedildi');
      else toast.error('Kaydetme hatası');
    } catch { toast.error('Hata'); } finally { setSaving(false); }
  };

  const updateSetting = (key: string, value: string) => setSettings(prev => ({ ...(prev ?? {}), [key]: value }));

  if (loading) return <div className="space-y-4">{[1,2].map((i: number) => <div key={i} className="h-32 bg-muted animate-pulse rounded-xl" />)}</div>;

  return (
    <div>
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="font-display text-2xl md:text-3xl font-bold tracking-tight">Ayarlar</h1>
          <p className="text-muted-foreground text-sm mt-1">Platform ayarlarını düzenleyin</p>
        </div>
        <Button onClick={handleSave} disabled={saving} className="gap-2">
          <Save className="h-4 w-4" /> {saving ? 'Kaydediliyor...' : 'Kaydet'}
        </Button>
      </div>

      <div className="space-y-6">
        <Card className="border-0 shadow-md">
          <CardContent className="p-6 space-y-4">
            <h2 className="font-display text-lg font-semibold flex items-center gap-2"><CreditCard className="h-5 w-5 text-primary" /> Ödeme Bilgileri</h2>
            <div>
              <label className="text-sm font-medium mb-1.5 block">IBAN</label>
              <Input placeholder="TR00 0000 0000 0000 0000 0000 00" value={settings?.iban ?? ''} onChange={(e: any) => updateSetting('iban', e?.target?.value ?? '')} />
            </div>
            <div>
              <label className="text-sm font-medium mb-1.5 block">Hesap Sahibi</label>
              <Input placeholder="Ad Soyad" value={settings?.account_holder ?? ''} onChange={(e: any) => updateSetting('account_holder', e?.target?.value ?? '')} />
            </div>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-md">
          <CardContent className="p-6 space-y-4">
            <h2 className="font-display text-lg font-semibold flex items-center gap-2"><Phone className="h-5 w-5 text-primary" /> İletişim Bilgileri</h2>
            <div>
              <label className="text-sm font-medium mb-1.5 block">WhatsApp Numara (başında 90)</label>
              <Input placeholder="905551234567" value={settings?.whatsapp_number ?? ''} onChange={(e: any) => updateSetting('whatsapp_number', e?.target?.value ?? '')} />
            </div>
            <div>
              <label className="text-sm font-medium mb-1.5 block">Instagram Kullanıcı Adı</label>
              <div className="relative">
                <Instagram className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input placeholder="dugunkareci" className="pl-10" value={settings?.instagram ?? ''} onChange={(e: any) => updateSetting('instagram', e?.target?.value ?? '')} />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-md">
          <CardContent className="p-6 space-y-4">
            <h2 className="font-display text-lg font-semibold flex items-center gap-2"><Settings className="h-5 w-5 text-primary" /> Paket Fiyatları</h2>
            <div className="grid sm:grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium mb-1.5 block">Basic Paket (₺)</label>
                <Input type="number" placeholder="500" value={settings?.price_basic ?? ''} onChange={(e: any) => updateSetting('price_basic', e?.target?.value ?? '')} />
              </div>
              <div>
                <label className="text-sm font-medium mb-1.5 block">Premium Paket (₺)</label>
                <Input type="number" placeholder="1000" value={settings?.price_premium ?? ''} onChange={(e: any) => updateSetting('price_premium', e?.target?.value ?? '')} />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
