'use client';

import { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { Heart, Camera, ShoppingCart, TrendingUp, Users } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { formatCurrency } from '@/lib/utils';

export function AdminDashboard() {
  const [stats, setStats] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('/api/admin/stats')
      .then(r => r.ok ? r.json() : null)
      .then(d => setStats(d))
      .catch(() => {})
      .finally(() => setLoading(false));
  }, []);

  const cards = [
    { label: 'Toplam Düğün', value: stats?.totalWeddings ?? 0, icon: Heart, color: 'text-pink-500' },
    { label: 'Toplam Fotoğraf', value: stats?.totalPhotos ?? 0, icon: Camera, color: 'text-blue-500' },
    { label: 'Bekleyen Sipariş', value: stats?.pendingOrders ?? 0, icon: ShoppingCart, color: 'text-orange-500' },
    { label: 'Toplam Gelir', value: formatCurrency(stats?.totalRevenue ?? 0), icon: TrendingUp, color: 'text-green-500' },
  ];

  return (
    <div>
      <div className="mb-8">
        <h1 className="font-display text-2xl md:text-3xl font-bold tracking-tight">Admin Dashboard</h1>
        <p className="text-muted-foreground text-sm mt-1">Platformun genel görünümü</p>
      </div>
      {loading ? (
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {[1,2,3,4].map((i: number) => <div key={i} className="h-32 bg-muted animate-pulse rounded-xl" />)}
        </div>
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {cards.map((c: any, i: number) => (
            <motion.div key={i} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.1 }}>
              <Card className="border-0 shadow-md hover:shadow-lg transition-all">
                <CardContent className="p-6">
                  <c.icon className={`h-8 w-8 ${c.color} mb-3`} />
                  <div className="font-display text-3xl font-bold">{c.value}</div>
                  <div className="text-sm text-muted-foreground mt-1">{c.label}</div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      )}
    </div>
  );
}
