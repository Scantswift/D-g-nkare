'use client';

import { useEffect, useState } from 'react';
import { ShoppingCart, Package, Clock, Truck, CheckCircle, XCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { formatCurrency, formatDate } from '@/lib/utils';
import { toast } from 'sonner';

const statusMap: Record<string, { label: string; color: string; icon: any }> = {
  PENDING: { label: 'Beklemede', color: 'bg-yellow-100 text-yellow-800', icon: Clock },
  PREPARING: { label: 'Hazırlanıyor', color: 'bg-blue-100 text-blue-800', icon: Package },
  SHIPPED: { label: 'Kargoda', color: 'bg-purple-100 text-purple-800', icon: Truck },
  DELIVERED: { label: 'Teslim Edildi', color: 'bg-green-100 text-green-800', icon: CheckCircle },
  CANCELLED: { label: 'İptal', color: 'bg-red-100 text-red-800', icon: XCircle },
};

export function OrdersManagement() {
  const [orders, setOrders] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchOrders = async () => {
    try {
      const res = await fetch('/api/admin/orders');
      if (res.ok) setOrders(await res.json() ?? []);
    } catch {} finally { setLoading(false); }
  };

  useEffect(() => { fetchOrders(); }, []);

  const updateStatus = async (id: string, status: string) => {
    try {
      const res = await fetch(`/api/admin/orders/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status }),
      });
      if (res.ok) {
        toast.success('Sipariş durumu güncellendi');
        fetchOrders();
      }
    } catch { toast.error('Güncellenemedi'); }
  };

  return (
    <div>
      <div className="mb-8">
        <h1 className="font-display text-2xl md:text-3xl font-bold tracking-tight">Sipariş Yönetimi</h1>
        <p className="text-muted-foreground text-sm mt-1">Baskı ve tablo siparişlerini yönetin</p>
      </div>
      {loading ? (
        <div className="space-y-4">{[1,2,3].map((i: number) => <div key={i} className="h-24 bg-muted animate-pulse rounded-xl" />)}</div>
      ) : (orders?.length ?? 0) === 0 ? (
        <Card className="border-dashed">
          <CardContent className="p-12 text-center">
            <ShoppingCart className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
            <p className="text-muted-foreground">Henüz sipariş yok</p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-4">
          {(orders ?? []).map((order: any) => {
            const st = statusMap[order?.status] ?? statusMap.PENDING;
            return (
              <Card key={order?.id} className="hover:shadow-md transition-all">
                <CardContent className="p-6">
                  <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <span className="font-mono text-sm font-semibold">{order?.orderNumber ?? ''}</span>
                        <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${st.color}`}>{st.label}</span>
                      </div>
                      <p className="text-sm"><strong>Düğün:</strong> {order?.wedding?.groomName ?? ''} & {order?.wedding?.brideName ?? ''}</p>
                      <p className="text-sm"><strong>Müşteri:</strong> {order?.customerName ?? ''} | {order?.customerPhone ?? ''}</p>
                      <p className="text-sm text-muted-foreground">{order?.customerAddress ?? ''}</p>
                      <p className="text-sm font-semibold mt-1">Tutar: {formatCurrency(order?.totalAmount ?? 0)}</p>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {['PENDING', 'PREPARING', 'SHIPPED', 'DELIVERED', 'CANCELLED'].map((s: string) => (
                        <Button key={s} size="sm" variant={order?.status === s ? 'default' : 'outline'}
                          onClick={() => updateStatus(order?.id, s)} className="text-xs">
                          {(statusMap[s] ?? statusMap.PENDING).label}
                        </Button>
                      ))}
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}
