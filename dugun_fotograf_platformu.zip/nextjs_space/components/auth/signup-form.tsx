'use client';

import { useState } from 'react';
import { signIn } from 'next-auth/react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { Heart, Mail, Lock, User, Phone, UserPlus } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { toast } from 'sonner';

export function SignupForm() {
  const router = useRouter();
  const [form, setForm] = useState({ firstName: '', lastName: '', email: '', phone: '', password: '', confirmPassword: '' });
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (form.password !== form.confirmPassword) {
      toast.error('Şifreler eşleşmiyor');
      return;
    }
    if ((form.password?.length ?? 0) < 6) {
      toast.error('Şifre en az 6 karakter olmalıdır');
      return;
    }
    setLoading(true);
    try {
      const res = await fetch('/api/signup', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ firstName: form.firstName, lastName: form.lastName, email: form.email, phone: form.phone, password: form.password }),
      });
      const data = await res.json();
      if (!res.ok) {
        toast.error(data?.error ?? 'Kayıt başarısız');
        return;
      }
      const result = await signIn('credentials', { email: form.email, password: form.password, redirect: false });
      if (result?.ok) {
        router.replace('/dashboard');
      } else {
        toast.error('Giriş yapılamadı');
      }
    } catch {
      toast.error('Bir hata oluştu');
    } finally {
      setLoading(false);
    }
  };

  const updateField = (field: string, value: string) => setForm(prev => ({ ...(prev ?? {}), [field]: value }));

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/5 via-background to-secondary/30 flex items-center justify-center p-4">
      <Card className="w-full max-w-md border-0 shadow-xl">
        <CardContent className="p-8">
          <div className="text-center mb-8">
            <Link href="/" className="inline-flex items-center gap-2 mb-4">
              <Heart className="h-8 w-8 text-primary fill-primary" />
              <span className="font-display text-2xl font-bold">DüğünKare</span>
            </Link>
            <h1 className="font-display text-xl font-semibold">Organizör Kayıt</h1>
            <p className="text-sm text-muted-foreground mt-1">Düğünlerinizi yönetmeye başlayın</p>
          </div>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium mb-1.5 block">Ad</label>
                <div className="relative">
                  <User className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input placeholder="Adınız" className="pl-10" value={form.firstName} onChange={(e: any) => updateField('firstName', e?.target?.value ?? '')} required />
                </div>
              </div>
              <div>
                <label className="text-sm font-medium mb-1.5 block">Soyad</label>
                <Input placeholder="Soyadınız" value={form.lastName} onChange={(e: any) => updateField('lastName', e?.target?.value ?? '')} required />
              </div>
            </div>
            <div>
              <label className="text-sm font-medium mb-1.5 block">Email</label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input type="email" placeholder="email@örnek.com" className="pl-10" value={form.email} onChange={(e: any) => updateField('email', e?.target?.value ?? '')} required />
              </div>
            </div>
            <div>
              <label className="text-sm font-medium mb-1.5 block">Telefon</label>
              <div className="relative">
                <Phone className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input placeholder="0555 123 45 67" className="pl-10" value={form.phone} onChange={(e: any) => updateField('phone', e?.target?.value ?? '')} />
              </div>
            </div>
            <div>
              <label className="text-sm font-medium mb-1.5 block">Şifre</label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input type="password" placeholder="En az 6 karakter" className="pl-10" value={form.password} onChange={(e: any) => updateField('password', e?.target?.value ?? '')} required />
              </div>
            </div>
            <div>
              <label className="text-sm font-medium mb-1.5 block">Şifre Tekrar</label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input type="password" placeholder="Şifrenizi tekrarlayın" className="pl-10" value={form.confirmPassword} onChange={(e: any) => updateField('confirmPassword', e?.target?.value ?? '')} required />
              </div>
            </div>
            <Button type="submit" className="w-full" size="lg" disabled={loading}>
              <UserPlus className="h-4 w-4 mr-2" />
              {loading ? 'Kayıt yapılıyor...' : 'Kayıt Ol'}
            </Button>
          </form>
          <p className="text-center text-sm text-muted-foreground mt-6">
            Zaten hesabınız var mı?{' '}
            <Link href="/giris" className="text-primary font-medium hover:underline">Giriş Yap</Link>
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
