'use client';

import { useState } from 'react';
import { signIn } from 'next-auth/react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { Heart, Mail, Lock, LogIn } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { toast } from 'sonner';

export function LoginForm() {
  const router = useRouter();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const result = await signIn('credentials', { email, password, redirect: false });
      if (result?.ok) {
        router.replace('/dashboard');
      } else {
        toast.error('Email veya şifre hatalı');
      }
    } catch {
      toast.error('Giriş sırasında hata oluştu');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/5 via-background to-secondary/30 flex items-center justify-center p-4">
      <Card className="w-full max-w-md border-0 shadow-xl">
        <CardContent className="p-8">
          <div className="text-center mb-8">
            <Link href="/" className="inline-flex items-center gap-2 mb-4">
              <Heart className="h-8 w-8 text-primary fill-primary" />
              <span className="font-display text-2xl font-bold">DüğünKare</span>
            </Link>
            <h1 className="font-display text-xl font-semibold">Giriş Yap</h1>
            <p className="text-sm text-muted-foreground mt-1">Hesabınıza giriş yapın</p>
          </div>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="text-sm font-medium mb-1.5 block">Email</label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input type="email" placeholder="email@örnek.com" className="pl-10" value={email} onChange={(e: any) => setEmail(e?.target?.value ?? '')} required />
              </div>
            </div>
            <div>
              <label className="text-sm font-medium mb-1.5 block">Şifre</label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input type="password" placeholder="Şifreniz" className="pl-10" value={password} onChange={(e: any) => setPassword(e?.target?.value ?? '')} required />
              </div>
            </div>
            <Button type="submit" className="w-full" size="lg" disabled={loading}>
              <LogIn className="h-4 w-4 mr-2" />
              {loading ? 'Giriş yapılıyor...' : 'Giriş Yap'}
            </Button>
          </form>
          <p className="text-center text-sm text-muted-foreground mt-6">
            Hesabınız yok mu?{' '}
            <Link href="/kayit" className="text-primary font-medium hover:underline">Kayıt Ol</Link>
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
