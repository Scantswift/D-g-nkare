'use client';

import { useEffect, useState, useCallback } from 'react';
import { QrCode, Download, Copy, Eye, Camera, Link2, Calendar, MapPin, ExternalLink, Image as ImageIcon } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { formatDate } from '@/lib/utils';
import { toast } from 'sonner';
import Link from 'next/link';

interface Photo {
  id: string;
  url: string;
  fileName: string;
  uploaderName: string | null;
  createdAt: string;
}

export function WeddingDetail({ weddingId }: { weddingId: string }) {
  const [wedding, setWedding] = useState<any>(null);
  const [photos, setPhotos] = useState<Photo[]>([]);
  const [qrData, setQrData] = useState<{ qrDataUrl: string; weddingUrl: string } | null>(null);
  const [loading, setLoading] = useState(true);

  const fetchData = useCallback(async () => {
    try {
      const [wRes, pRes, qRes] = await Promise.all([
        fetch(`/api/weddings/${weddingId}`),
        fetch(`/api/weddings/${weddingId}/photos`),
        fetch(`/api/weddings/${weddingId}/qr`),
      ]);
      if (wRes.ok) setWedding(await wRes.json());
      if (pRes.ok) setPhotos(await pRes.json() ?? []);
      if (qRes.ok) setQrData(await qRes.json());
    } catch { /* ignore */ } finally { setLoading(false); }
  }, [weddingId]);

  useEffect(() => { fetchData(); }, [fetchData]);

  const downloadQR = () => {
    if (!qrData?.qrDataUrl) return;
    const link = document.createElement('a');
    link.download = `qr-${wedding?.slug ?? 'dugun'}.png`;
    link.href = qrData.qrDataUrl;
    link.click();
  };

  const copyLink = () => {
    if (!qrData?.weddingUrl) return;
    navigator.clipboard?.writeText?.(qrData.weddingUrl);
    toast.success('Link kopyalandı!');
  };

  if (loading) return <div className="space-y-4">{[1,2,3].map((i: number) => <div key={i} className="h-32 bg-muted animate-pulse rounded-xl" />)}</div>;
  if (!wedding) return <p className="text-center text-muted-foreground py-12">Düğün bulunamadı</p>;

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl md:text-3xl font-bold tracking-tight">{wedding?.groomName} & {wedding?.brideName}</h1>
          <div className="flex items-center gap-4 mt-2 text-sm text-muted-foreground">
            <span className="flex items-center gap-1"><Calendar className="h-3.5 w-3.5" /> {formatDate(wedding?.weddingDate)}</span>
            {wedding?.venue && <span className="flex items-center gap-1"><MapPin className="h-3.5 w-3.5" /> {wedding.venue}</span>}
          </div>
        </div>
        <div className="flex gap-2">
          <Badge>{wedding?.packageType === 'premium' ? 'Premium' : 'Basic'}</Badge>
          <Badge variant={wedding?.isActive ? 'default' : 'secondary'}>{wedding?.isActive ? 'Aktif' : 'Pasif'}</Badge>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { label: 'Fotoğraf', value: photos?.length ?? 0, icon: Camera },
          { label: 'Görüntülenme', value: wedding?.viewCount ?? 0, icon: Eye },
          { label: 'Sipariş', value: wedding?._count?.orders ?? 0, icon: ImageIcon },
          { label: 'Paket', value: wedding?.packageType === 'premium' ? 'Premium' : 'Basic', icon: Link2 },
        ].map((s: any, i: number) => (
          <Card key={i} className="border-0 bg-secondary/30">
            <CardContent className="p-4 text-center">
              <s.icon className="h-5 w-5 text-primary mx-auto mb-2" />
              <div className="font-display text-2xl font-bold">{s.value}</div>
              <div className="text-xs text-muted-foreground">{s.label}</div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* QR Code */}
      <Card className="border-0 shadow-lg">
        <CardContent className="p-8">
          <h2 className="font-display text-xl font-bold mb-6 flex items-center gap-2"><QrCode className="h-5 w-5 text-primary" /> QR Kod & Link</h2>
          <div className="flex flex-col md:flex-row items-center gap-8">
            {qrData?.qrDataUrl && (
              <div className="bg-white p-4 rounded-2xl shadow-md">
                <img src={qrData.qrDataUrl} alt="QR Kod" className="w-48 h-48" />
              </div>
            )}
            <div className="flex-1 space-y-4">
              <div>
                <label className="text-sm text-muted-foreground mb-1 block">Düğün Linki</label>
                <div className="flex items-center gap-2">
                  <code className="flex-1 bg-muted px-3 py-2 rounded-lg text-sm break-all">{qrData?.weddingUrl ?? ''}</code>
                  <Button size="sm" variant="outline" onClick={copyLink} className="gap-1.5 flex-shrink-0">
                    <Copy className="h-3.5 w-3.5" /> Kopyala
                  </Button>
                </div>
              </div>
              <div className="flex flex-wrap gap-2">
                <Button onClick={downloadQR} className="gap-2"><Download className="h-4 w-4" /> QR Kodu İndir (PNG)</Button>
                <Link href={`/dugun/${wedding?.slug}`} target="_blank">
                  <Button variant="outline" className="gap-2"><ExternalLink className="h-4 w-4" /> Galeriyi Gör</Button>
                </Link>
              </div>
              <p className="text-xs text-muted-foreground">Bu QR kodu indirup düğün mekanına yerleştirin. Misafirler QR kodu okutarak galeri sayfasına ulaşabilir.</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Photos */}
      <div>
        <h2 className="font-display text-xl font-bold mb-4 flex items-center gap-2"><Camera className="h-5 w-5 text-primary" /> Yüklenen Fotoğraflar ({photos?.length ?? 0})</h2>
        {(photos?.length ?? 0) === 0 ? (
          <Card className="border-dashed">
            <CardContent className="p-12 text-center">
              <Camera className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
              <p className="text-muted-foreground">Henüz fotoğraf yüklenmedi. Misafirler QR kodu okutarak fotoğraf yükleyebilir.</p>
            </CardContent>
          </Card>
        ) : (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {(photos ?? []).map((p: Photo) => (
              <Card key={p.id} className="overflow-hidden group">
                <div className="aspect-square relative bg-muted">
                  <img src={p.url} alt={p.fileName ?? 'Fotoğraf'} className="w-full h-full object-cover" loading="lazy" />
                </div>
                <CardContent className="p-3">
                  <p className="text-xs text-muted-foreground truncate">{p.uploaderName || 'Anonim'}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
