'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { Heart, Calendar, MapPin, Package } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { toast } from 'sonner';

export function CreateWeddingForm() {
  const router = useRouter();
  const [form, setForm] = useState({ groomName: '', brideName: '', weddingDate: '', venue: '', packageType: 'basic' });
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const res = await fetch('/api/weddings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form),
      });
      if (res.ok) {
        const data = await res.json();
        toast.success('Düğün başarıyla oluşturuldu!');
        router.replace(`/dashboard/dugun/${data?.id}`);
      } else {
        const err = await res.json();
        toast.error(err?.error ?? 'Oluşturulamadı');
      }
    } catch {
      toast.error('Hata oluştu');
    } finally {
      setLoading(false);
    }
  };

  const updateField = (field: string, value: string) => setForm(prev => ({ ...(prev ?? {}), [field]: value }));

  return (
    <div className="max-w-2xl mx-auto">
      <div className="mb-8">
        <h1 className="font-display text-2xl md:text-3xl font-bold tracking-tight">Yeni Düğün Oluştur</h1>
        <p className="text-muted-foreground text-sm mt-1">Düğün bilgilerini girin, sistem otomatik QR kod oluşturacak</p>
      </div>
      <Card className="border-0 shadow-lg">
        <CardContent className="p-8">
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="grid sm:grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium mb-1.5 block">Damat Adı *</label>
                <div className="relative">
                  <Heart className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input placeholder="Damat adı" className="pl-10" value={form.groomName} onChange={(e: any) => updateField('groomName', e?.target?.value ?? '')} required />
                </div>
              </div>
              <div>
                <label className="text-sm font-medium mb-1.5 block">Gelin Adı *</label>
                <div className="relative">
                  <Heart className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-primary" />
                  <Input placeholder="Gelin adı" className="pl-10" value={form.brideName} onChange={(e: any) => updateField('brideName', e?.target?.value ?? '')} required />
                </div>
              </div>
            </div>
            <div>
              <label className="text-sm font-medium mb-1.5 block">Düğün Tarihi *</label>
              <div className="relative">
                <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input type="date" className="pl-10" value={form.weddingDate} onChange={(e: any) => updateField('weddingDate', e?.target?.value ?? '')} required />
              </div>
            </div>
            <div>
              <label className="text-sm font-medium mb-1.5 block">Düğün Yeri</label>
              <div className="relative">
                <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input placeholder="Ör: Gül Bahçesi, İstanbul" className="pl-10" value={form.venue} onChange={(e: any) => updateField('venue', e?.target?.value ?? '')} />
              </div>
            </div>
            <div>
              <label className="text-sm font-medium mb-1.5 block">Paket Seçimi</label>
              <div className="grid grid-cols-2 gap-4">
                {[{ val: 'basic', label: 'Basic', desc: '500 ₺' }, { val: 'premium', label: 'Premium', desc: '1.000 ₺' }].map((p: any) => (
                  <button key={p.val} type="button" onClick={() => updateField('packageType', p.val)}
                    className={`p-4 rounded-xl border-2 text-left transition-all ${form.packageType === p.val ? 'border-primary bg-primary/5' : 'border-border hover:border-primary/30'}`}>
                    <div className="flex items-center gap-2">
                      <Package className={`h-4 w-4 ${form.packageType === p.val ? 'text-primary' : 'text-muted-foreground'}`} />
                      <span className="font-semibold">{p.label}</span>
                    </div>
                    <p className="text-sm text-muted-foreground mt-1">{p.desc}</p>
                  </button>
                ))}
              </div>
            </div>
            <Button type="submit" className="w-full" size="lg" disabled={loading}>
              {loading ? 'Oluşturuluyor...' : 'Düğün Oluştur'}
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
