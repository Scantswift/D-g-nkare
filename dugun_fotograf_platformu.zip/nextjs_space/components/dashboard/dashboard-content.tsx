'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import { motion } from 'framer-motion';
import { Plus, Calendar, MapPin, Eye, Camera, QrCode, ExternalLink, Trash2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { formatDate } from '@/lib/utils';
import { toast } from 'sonner';

interface Wedding {
  id: string;
  groomName: string;
  brideName: string;
  weddingDate: string;
  venue: string | null;
  slug: string;
  packageType: string;
  isActive: boolean;
  viewCount: number;
  _count: { photos: number; orders: number };
}

export function DashboardContent() {
  const [weddings, setWeddings] = useState<Wedding[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchWeddings = async () => {
    try {
      const res = await fetch('/api/weddings');
      if (res.ok) {
        const data = await res.json();
        setWeddings(data ?? []);
      }
    } catch { /* ignore */ } finally { setLoading(false); }
  };

  useEffect(() => { fetchWeddings(); }, []);

  const handleDelete = async (id: string) => {
    if (!confirm('Bu düğünü silmek istediğinize emin misiniz?')) return;
    try {
      const res = await fetch(`/api/weddings/${id}`, { method: 'DELETE' });
      if (res.ok) {
        toast.success('Düğün silindi');
        fetchWeddings();
      }
    } catch { toast.error('Silinemedi'); }
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="font-display text-2xl md:text-3xl font-bold tracking-tight">Düğünlerim</h1>
          <p className="text-muted-foreground text-sm mt-1">Oluşturduğunuz düğünleri yönetin</p>
        </div>
        <Link href="/dashboard/yeni">
          <Button className="gap-2"><Plus className="h-4 w-4" /> Yeni Düğün</Button>
        </Link>
      </div>

      {loading ? (
        <div className="grid md:grid-cols-2 gap-6">
          {[1,2].map((i: number) => <div key={i} className="h-48 bg-muted animate-pulse rounded-xl" />)}
        </div>
      ) : (weddings?.length ?? 0) === 0 ? (
        <Card className="border-dashed">
          <CardContent className="p-12 text-center">
            <Calendar className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
            <h3 className="font-semibold text-lg mb-2">Henüz düğün oluşturmadınız</h3>
            <p className="text-muted-foreground mb-4">Hemen ilk düğününüzü oluşturun ve QR kodunuzu alın</p>
            <Link href="/dashboard/yeni"><Button className="gap-2"><Plus className="h-4 w-4" /> Yeni Düğün Oluştur</Button></Link>
          </CardContent>
        </Card>
      ) : (
        <div className="grid md:grid-cols-2 gap-6">
          {(weddings ?? []).map((w: Wedding, i: number) => (
            <motion.div key={w.id} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.1 }}>
              <Card className="hover:shadow-lg transition-all duration-300 overflow-hidden">
                <CardContent className="p-6">
                  <div className="flex items-start justify-between mb-4">
                    <div>
                      <h3 className="font-display text-xl font-bold">{w.groomName} & {w.brideName}</h3>
                      <div className="flex items-center gap-4 mt-2 text-sm text-muted-foreground">
                        <span className="flex items-center gap-1"><Calendar className="h-3.5 w-3.5" /> {formatDate(w.weddingDate)}</span>
                        {w.venue && <span className="flex items-center gap-1"><MapPin className="h-3.5 w-3.5" /> {w.venue}</span>}
                      </div>
                    </div>
                    <Badge variant={w.isActive ? 'default' : 'secondary'}>{w.isActive ? 'Aktif' : 'Pasif'}</Badge>
                  </div>
                  <div className="flex items-center gap-4 mb-4 text-sm">
                    <span className="flex items-center gap-1 text-muted-foreground"><Camera className="h-4 w-4" /> {w._count?.photos ?? 0} fotoğraf</span>
                    <span className="flex items-center gap-1 text-muted-foreground"><Eye className="h-4 w-4" /> {w.viewCount ?? 0} görüntülenme</span>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    <Link href={`/dashboard/dugun/${w.id}`}>
                      <Button size="sm" variant="secondary" className="gap-1.5"><QrCode className="h-3.5 w-3.5" /> Yönet</Button>
                    </Link>
                    <Link href={`/dugun/${w.slug}`} target="_blank">
                      <Button size="sm" variant="outline" className="gap-1.5"><ExternalLink className="h-3.5 w-3.5" /> Galeri</Button>
                    </Link>
                    <Button size="sm" variant="ghost" className="gap-1.5 text-destructive hover:text-destructive" onClick={() => handleDelete(w.id)}>
                      <Trash2 className="h-3.5 w-3.5" /> Sil
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      )}
    </div>
  );
}
