'use client';

import { useSession, signOut } from 'next-auth/react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { Heart, LayoutDashboard, Plus, LogOut, Settings, Menu, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useState } from 'react';

export function DashboardLayout({ children }: { children: React.ReactNode }) {
  const { data: session } = useSession() || {};
  const pathname = usePathname();
  const [mobileOpen, setMobileOpen] = useState(false);

  const navItems = [
    { href: '/dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { href: '/dashboard/yeni', label: 'Yeni Düğün', icon: Plus },
  ];

  const isAdmin = (session?.user as any)?.role === 'ADMIN';

  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-50 bg-background/80 backdrop-blur-md border-b border-border/50">
        <div className="max-w-[1200px] mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" className="md:hidden" onClick={() => setMobileOpen(!mobileOpen)}>
              {mobileOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </Button>
            <Link href="/dashboard" className="flex items-center gap-2">
              <Heart className="h-6 w-6 text-primary fill-primary" />
              <span className="font-display text-xl font-bold tracking-tight">DüğünKare</span>
            </Link>
          </div>
          <nav className="hidden md:flex items-center gap-1">
            {navItems.map((item: any) => (
              <Link key={item.href} href={item.href}>
                <Button variant={pathname === item.href ? 'secondary' : 'ghost'} size="sm" className="gap-2">
                  <item.icon className="h-4 w-4" />
                  {item.label}
                </Button>
              </Link>
            ))}
            {isAdmin && (
              <Link href="/admin">
                <Button variant={pathname?.startsWith('/admin') ? 'secondary' : 'ghost'} size="sm" className="gap-2">
                  <Settings className="h-4 w-4" /> Admin
                </Button>
              </Link>
            )}
          </nav>
          <div className="flex items-center gap-3">
            <span className="text-sm text-muted-foreground hidden sm:block">{session?.user?.name ?? ''}</span>
            <Button variant="ghost" size="sm" onClick={() => signOut({ callbackUrl: '/' })} className="gap-2">
              <LogOut className="h-4 w-4" /> Çıkış
            </Button>
          </div>
        </div>
      </header>
      {mobileOpen && (
        <div className="md:hidden border-b border-border bg-background p-4 space-y-2">
          {navItems.map((item: any) => (
            <Link key={item.href} href={item.href} onClick={() => setMobileOpen(false)}>
              <Button variant={pathname === item.href ? 'secondary' : 'ghost'} className="w-full justify-start gap-2">
                <item.icon className="h-4 w-4" /> {item.label}
              </Button>
            </Link>
          ))}
          {isAdmin && (
            <Link href="/admin" onClick={() => setMobileOpen(false)}>
              <Button variant="ghost" className="w-full justify-start gap-2">
                <Settings className="h-4 w-4" /> Admin
              </Button>
            </Link>
          )}
        </div>
      )}
      <main className="max-w-[1200px] mx-auto px-4 py-8">{children}</main>
    </div>
  );
}
